<?php
   error_reporting(0); 

   // Affiliate Id
   $affiliate_id = '136';

   // Site Name
   $name = 'Web Hosting';

   // Site Slogan / Headline / Title
   $slogan = 'Trusted Hosting Provider';

   // Site Logo
   $logo = 'img/header/wh-logo.png';

   // Menu Btn Text
   $btn_text = 'Client Area';

   // Menu Btn Link
   $btn_link = 'https://panel.amarhoster.com/aff.php?aff='.$affiliate_id;

   // Footer Copyright
   $copyright = '&copy; 2022 Company Name | All Right Reserved';


   // Hosting Page Title

   // Cloud Hosting Title
   $cloud_hosting = 'Pay Per Use Cloud Hosting';

   // Premium cPanel Hosting Title
   $premium_cpanel = 'Premium cPanel Web Hosting';

   // cPanel Reseller Hosting Title
   $cpanel_reseller = 'cPanel Reseller Hosting';

   // cPanel Vps Server Hosting Title
   $cpanel_vps_server = 'Managed Vps Server';

   // Student Hosting Title
   $student_hosting = 'Student Web Hosting Zero Budget';

   // Bundle Hosting Free Domain Title
   $bundle_hosting = 'Cheap Bundle Hosting With Free Domain';

   // Bdix Budget Web Hosting Title
   $bdix_budget_web = 'Bdix Budget Web Hosting';

   // Bdix Premium Web Hosting Title
   $bdix_premium_web = 'Bdix Premium Web Hosting';

   // Bdix Reseller Hosting Title
   $bdix_reseller = 'Bdix Reseller Hosting';

   // SMM Web Hosting Title
   $smm_web_hosting = 'SMM Optimized Web Hosting';

   // DMCA Ignored Hosting Title
   $dmca_ignored_hosting = 'DMCA Ignored Offshore Hosting';
   
   // Budget Web Hosting Title
   $budget_web = 'Budget Web Hosting';
?>