<?php include "site-info.php";?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Bredh flat responsive HTML & WHMCS hosting and domains template">
    <meta name="author" content="coodiv.net (nedjai mohamed)">
    <link rel="canonical" href="https://coodiv.net/blog/"/>
    <link rel="icon" href="favicon.ico">
    <title><?php echo $name;?> | <?php echo $bundle_hosting;?></title>
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Coodiv creative agency blog" />
    <meta property="og:description" content="We specialize in coding, designing interfaces, web experiences and meaningful products, we’re pretty good at it." />
    <meta property="og:url" content="https://coodiv.net/blog/" />
    <meta property="og:site_name" content="Coodiv creative agency blog" />
    <meta property="og:image" content="https://coodiv.net/blog/wp-content/uploads/2022/05/placeholder.jpg" />
    <meta property="og:image:width" content="1800" />
    <meta property="og:image:height" content="900" />
    <meta property="og:image:type" content="image/jpeg" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:site" content="@coodiv" />
	
	<!-- Bootstrap , fonts & icons -->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="icons-pack/fontawesome-5/css/all.css" rel="stylesheet" />


    <!-- main css file -->
    <link href="css/main.min.css" rel="stylesheet" />

</head>

<body><!-- start body -->

    <div class="preloader">
        <!-- start preloader -->
        <div class="preloader-container">
            <svg version="1.1" id="L5" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 0 0" xml:space="preserve">
                <circle fill="#675cda" stroke="none" cx="6" cy="50" r="6">
                    <animateTransform attributeName="transform" dur="1s" type="translate" values="0 15 ; 0 -15; 0 15" repeatCount="indefinite" begin="0.1" />
                </circle>
                <circle fill="#675cda" stroke="none" cx="30" cy="50" r="6">
                    <animateTransform attributeName="transform" dur="1s" type="translate" values="0 10 ; 0 -10; 0 10" repeatCount="indefinite" begin="0.2" />
                </circle>
                <circle fill="#675cda" stroke="none" cx="54" cy="50" r="6">
                    <animateTransform attributeName="transform" dur="1s" type="translate" values="0 5 ; 0 -5; 0 5" repeatCount="indefinite" begin="0.3" />
                </circle>
            </svg>
            <span>loading</span>
        </div>
    </div>
    <!-- end preloader -->

    <div id="coodiv-header" class="d-flex mx-auto flex-column moon-edition services-page">
    <span style="background: #c1efff;" class="services-page-bg-overflow"></span>
        <!-- Fixed navbar -->
        <nav id="coodiv-navbar-header" class="navbar navbar-expand-md fixed-header-layout">
                <div class="container main-header-coodiv-s">
                    <a class="navbar-brand" href="index.php">
                        <img class="w-logo" src="<?php echo $logo;?>" alt="" />
                        <img class="b-logo" src="<?php echo $logo;?>" alt="" />
                    </a>
                    <button class="navbar-toggle offcanvas-toggle menu-btn-span-bar ml-auto" data-toggle="offcanvas" data-target="#offcanvas-menu-home">
                        <span></span>
                        <span></span>
                        <span></span>
                    </button>
                    <div class="collapse navbar-collapse navbar-offcanvas" id="offcanvas-menu-home">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item mega-menu demos-dropdown dropdown active">
                            <a class="nav-link" href="index.php" role="button">Home</a>
                            </li>

                            <li class="nav-item dropdown">
                                <a class="nav-link" role="button" id="webhosting-megamenu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#">Global Hosting</a>
                                <div class="dropdown-menu coodiv-menu-dropdown coodiv-dropdown-header web-menu" aria-labelledby="webhosting-megamenu">
                                    <div class="dropdown-menu-wrapper min-padding">
                                        <ul class="web-hosting-menu-header">
                                            <li>
                                                <a href="cloud-hosting.php">Pay Per Use Cloud Hosting</a>
                                            </li>
                                            <li>
                                                <a href="premium-cpanel.php">Premium cPanel Hosting </a>
                                            </li>
                                            <li>
                                                <a href="cpanel-reseller.php">cPanel Reseller Hosting</a>
                                            </li>
                                            <li>
                                                <a href="cpanel-vps-server.php">cPanel Vps Server Hosting</a>
                                            </li>
                                            <li>
                                                <a href="student-hosting.php">Student Hosting</a>
                                            </li>
                                            <li>
                                                <a href="bundle-hosting.php">Hosting Bundle Free Domain</a>
                                            </li>
                                            <li>
                                                <a href="smm-web-hosting.php">SMM Optimaized Hosting </a>
                                            </li>
                                            <li>
                                                <a href="dmca-ignored-hosting.php">DMCA Ignored Hosting </a>
                                            </li>
                                            <li>
                                                <a href="budget-web-hosting.php">Budget Web Hosting </a>
</li>
                                        </ul>
                                    </div>
                                </div>
                            </li>

                            <li class="nav-item dropdown">
                                <a class="nav-link" href="#" role="button" id="header-help-drop-down" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">BDIX Hosting<span class="sr-only">(current)</span></a>
                                <ul class="dropdown-menu coodiv-menu-dropdown coodiv-dropdown-header" aria-labelledby="header-help-drop-down">
                                    <div class="dropdown-menu-wrapper min-padding">
                                        <li><a class="dropdown-item" href="bdix-budget-hosting.php">BDIX Budget Hosting</a></li>
                                        <li><a class="dropdown-item" href="bdix-premium-hosting.php">BDIX Premium Hosting</a></li>
                                        <li><a class="dropdown-item" href="bdix-reseller-hosting.php">BDIX Reseller Hosting</a></li>
                                    </div>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link" href="https://panel.amarhoster.com/aff.php?aff=<?php echo $affiliate_id;?>">Register A New Domain</a>
                            </li>
                        </ul>
                    </div>
                    <ul class="header-user-info-coodiv">
                        <li class="dropdown">
                        <a role="button" id="header-login-dropdown" href="<?php echo $btn_link;?>"><?php echo $btn_text;?></a>
                        </li>
                    </ul>
                </div>
            </nav>
		
		
        <main class="container pt-30">
		
		    <div class="row justify-content-start">
                  <div class="col-md-7 col-12 white-text">
                  <span class="main-header-top-title">কম্বো</span>
                  <h3 class="main-header-title coodiv-text-3 font-weight-bold mb-9">চিপ হোস্টিং ফ্রী ডোমেইন
</h3>
                  <p>ওয়েব হোস্টিং হল এক ধরনের পরিষেবা যা ইন্টারনেটে যেকোনো ব্যক্তি বা প্রতিষ্ঠানের ওয়েবসাইট অ্যাক্সেসযোগ্য করে তোলে।</p>
                  <p>দেশে অর্থনৈতিক অস্থিতিশীলতা চলমান থাকা সত্ত্বেও আমার হোস্টার সর্বোচ্চ ছাড় এ ওয়েব হোস্টিং ও ফ্রী ডোমেইন সরবরাহ করছে। এখন মাত্র ১৫০০ টাকায় ১০ জিবি NVMe সিপ্যানেল হোস্টিং ও ফ্রী ডটকম বা XYZ ডোমেইন নেয়া যাবে ।</p>
                  <div class="d-flex mt-5"><a class="main-header-btn coodiv-text-9 font-weight-bold" href="#pricing">বান্ডেল হোস্টিং প্যাকেজ দেখুন <i class="fal fa-arrow-right"></i></a></div>
                  </div>
				  
				  <div class="col-10 col-md-5 mt-fox-14">
				  <img src="img/demo/hosting/bundle-domain-hosting-amarHoster.png" class="d-block mx-lg-auto img-fluid mt-n10 mb-15" alt="Bootstrap Themes" width="640" height="584" loading="lazy">
				  </div>
            </div>
        </main>

		</div>
		
    </div>

	
	<section class="pt-20 pb-25">
	<div class="container">
	<h5 class="title-default-coodiv-two" id="pricing">বান্ডেল হোস্টিং প্যাকেজ</h5>
	<div class="row justify-content-center">
	<div class="col-md-4 cpanel-resslers-plan">
	<div class="cpanel-resslers-plan-header">
	<h5>DH 10G</h5>
	<span>৳১৫০০</span> 
    <h4 class="text-white mt-1">প্রতি বছর</h4>
	</div>
	<div class="cpanel-resslers-plan-body">
	<p><strong>প্রথম বছর ফ্রী .COM বা .XYZ</strong></p>
	<p><strong>১০ জিবি এনভিএমি স্টোরেজ</strong></p>
	<p><strong>৪ অ্যাডঅন ডোমেইন</strong></p>
	<p><strong>1 GB RAM</strong></p>
	<p><strong>1 Core CPU</strong></p>
	<p><strong>100 NRPROC</strong></p>
    <p><strong>20 EP, 5 MB/s IO</strong></p>
    <p><strong>আনলিমিটেড সাবডোমেইন</strong></p>
    <p><strong>আনমিটারড মাসিক ব্যান্ডউইথ</strong></p>
    <p><strong>আনলিমিটেড ডাটাবেস</strong></p>
    <p><strong>আনলিমিটেড ইমেইল</strong></p>
    <p><strong>ফ্রি আনলিমিটেড SSL</strong></p>
    <p><strong>৯৯.৯% আপটাইম গ্যারান্টি</strong></p>
    <p>সিপ্যানেল কন্ট্রোল প্যানেল</p>
    <p>লাইটস্পিড ওয়েব সার্ভার</p>
    <p>ক্লাউডলিনাক্স আইসলেশন</p>
    <p>সফটাকুলাস অ্যাাপ ইন্সটলার</p>
    <p>সাইটপ্যাড বিল্ডার</p>
    <p>ইমিউনিফাই সিকিউরিটি</p>
    <p>ফ্রি ব্যাকাপ ও রিস্টোর</p>
    <p>ফ্রি সিইও টুলস</p>
    <p>Shell অ্যাক্সেস</p>
    <p>৩০ দিন মানি ব্যাক গ্যারান্টি</p>
    <p>PHP, Python, Ruby, Node.js</p>
    <p>আমেরিকা / ইউরোপ লোকেশন</p>
    <p>প্রিমিয়াম সাপোর্ট সিস্টেম</p>
	</div>
	<div class="cpanel-resslers-plan-footer">
	<a href="https://panel.amarhoster.com/aff.php?aff=<?php echo $affiliate_id;?>&pid=118">এখনি কিনুন</a>
	</div>
	</div>
	
	<div class="col-md-4 cpanel-resslers-plan">
	<div class="cpanel-resslers-plan-header t">
	<h5>DH 25G</h5>
	<span>৳২৫০০</span> 
    <h4 class="text-white mt-1">প্রতি বছর</h4>
	</div>
	<div class="cpanel-resslers-plan-body">
	<p><strong>প্রথম বছর ফ্রী .COM বা .XYZ</strong></p>
	<p><strong>২৫ জিবি এনভিএমি স্টোরেজ</strong></p>
	<p><strong>৯ অ্যাডঅন ডোমেইন</strong></p>
	<p><strong>2 GB RAM</strong></p>
	<p><strong>2 Core CPU</strong></p>
	<p><strong>100 NRPROC</strong></p>
    <p><strong>40 EP, 10 MB/s IO</strong></p>
    <p><strong>আনলিমিটেড সাবডোমেইন</strong></p>
    <p><strong>আনমিটারড মাসিক ব্যান্ডউইথ</strong></p>
    <p><strong>আনলিমিটেড ডাটাবেস</strong></p>
    <p><strong>আনলিমিটেড ইমেইল</strong></p>
    <p><strong>ফ্রি আনলিমিটেড SSL</strong></p>
    <p><strong>৯৯.৯% আপটাইম গ্যারান্টি</strong></p>
    <p>সিপ্যানেল কন্ট্রোল প্যানেল</p>
    <p>লাইটস্পিড ওয়েব সার্ভার</p>
    <p>ক্লাউডলিনাক্স আইসলেশন</p>
    <p>সফটাকুলাস অ্যাাপ ইন্সটলার</p>
    <p>সাইটপ্যাড বিল্ডার</p>
    <p>ইমিউনিফাই সিকিউরিটি</p>
    <p>ফ্রি ব্যাকাপ ও রিস্টোর</p>
    <p>ফ্রি সিইও টুলস</p>
    <p>Shell অ্যাক্সেস</p>
    <p>৩০ দিন মানি ব্যাক গ্যারান্টি</p>
    <p>PHP, Python, Ruby, Node.js</p>
    <p>আমেরিকা / ইউরোপ লোকেশন</p>
    <p>প্রিমিয়াম সাপোর্ট সিস্টেম</p>
	</div>
	<div class="cpanel-resslers-plan-footer t">
	<a href="https://panel.amarhoster.com/aff.php?aff=<?php echo $affiliate_id;?>&pid=119">এখনি কিনুন</a>
	</div>
	</div>

    <div class="col-md-4 cpanel-resslers-plan">
	<div class="cpanel-resslers-plan-header">
	<h5>DH 50G</h5>
	<span>৳৫০০০</span> 
    <h4 class="text-white mt-1">প্রতি বছর</h4>
	</div>
	<div class="cpanel-resslers-plan-body">
	<p><strong>প্রথম বছর ফ্রী .COM বা .XYZ</strong></p>
	<p><strong>৫০ জিবি এনভিএমি স্টোরেজ</strong></p>
	<p><strong>১৪ অ্যাডঅন ডোমেইন</strong></p>
	<p><strong>2 GB RAM</strong></p>
	<p><strong>2 Core CPU</strong></p>
	<p><strong>100 NRPROC</strong></p>
    <p><strong>40 EP, 10 MB/s IO</strong></p>
    <p><strong>আনলিমিটেড সাবডোমেইন</strong></p>
    <p><strong>আনমিটারড মাসিক ব্যান্ডউইথ</strong></p>
    <p><strong>আনলিমিটেড ডাটাবেস</strong></p>
    <p><strong>আনলিমিটেড ইমেইল</strong></p>
    <p><strong>ফ্রি আনলিমিটেড SSL</strong></p>
    <p><strong>৯৯.৯% আপটাইম গ্যারান্টি</strong></p>
    <p>সিপ্যানেল কন্ট্রোল প্যানেল</p>
    <p>লাইটস্পিড ওয়েব সার্ভার</p>
    <p>ক্লাউডলিনাক্স আইসলেশন</p>
    <p>সফটাকুলাস অ্যাাপ ইন্সটলার</p>
    <p>সাইটপ্যাড বিল্ডার</p>
    <p>ইমিউনিফাই সিকিউরিটি</p>
    <p>ফ্রি ব্যাকাপ ও রিস্টোর</p>
    <p>ফ্রি সিইও টুলস</p>
    <p>Shell অ্যাক্সেস</p>
    <p>৩০ দিন মানি ব্যাক গ্যারান্টি</p>
    <p>PHP, Python, Ruby, Node.js</p>
    <p>আমেরিকা / ইউরোপ লোকেশন</p>
    <p>প্রিমিয়াম সাপোর্ট সিস্টেম</p>
	</div>
	<div class="cpanel-resslers-plan-footer">
	<a href="https://panel.amarhoster.com/aff.php?aff=<?php echo $affiliate_id;?>&pid=120">এখনি কিনুন</a>
	</div>
	</div>
	
	</div>

	</div>
	</section>

    <section class="py-20 bg-default-2">
            <div class="container">
                <h5 class="title-default-coodiv-two">কেন আমাদের পছন্দ করবেন?</h5>

                <div class="row justify-content-center mt-10">
                    <div class="col-md-4">
                        <div class="coodiv-feutres-black-version">
                            <i style="background: #88f6ec;" class="fad fa-chart-pie"></i>
                            <div class="text">
                                <h5 class="coodiv-text-7 font-weight-bold mb-0">৯৯.৯% আপটাইম গ্যারান্টি</h5>
                                <p class="coodiv-text-11 font-weight-light">ওয়েবসাইট 24×7 অনলাইনে রাখতে আমরা 99.99% আপটাইম গ্যারান্টি নিশ্চিত করি।</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="coodiv-feutres-black-version">
                            <i style="background: #79f9c0;" class="fad fa-bell"></i>
                            <div class="text">
                                <h5 class="coodiv-text-7 font-weight-bold mb-0">সম্পূর্ণ এবং বিনামূল্যে সাপোর্ট</h5>
                                <p class="coodiv-text-11 font-weight-light">যেকোন প্রশ্নে আপনাকে সাপোর্ট করার জন্য আমরা সার্বক্ষণিক উপলব্ধ।</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="coodiv-feutres-black-version">
                            <i style="background: #fede48;" class="fad fa-binoculars"></i>
                            <div class="text">
                                <h5 class="coodiv-text-7 font-weight-bold mb-0">মানি ব্যাক গ্যারান্টি</h5>
                                <p class="coodiv-text-11 font-weight-light">আমরা নতুন ক্লায়েন্ট দের জন্য ৩০ দিনের মানি ব্যাক গ্যারান্টি সুবিধা প্রদান করে থাকি।</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="footer-section">
            <div class="container">

                <div class="row justify-content-between final-footer-area">
                    <div class="col-md col-12">
                        <div class="final-footer-area-text"><?php echo $copyright;?></div>
                    </div>
                    <div class="col-md col-12 d-flex justify-content-end">
                        <div class="footer-lang-changer">
                            <div class="lang-changer-drop-up">
                                <a class="menu-btn-changer" role="button" id="dropupmenulagchanger" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#"><i class="fas fa-globe-asia"></i> english</a>
                                <div class="dropdown-menu dropupmenulagchanger" aria-labelledby="dropupmenulagchanger">
                                    <a class="dropdown-item" href="#">english</a>
                                    <a class="dropdown-item" href="#">العربية</a>
                                    <a class="dropdown-item" href="#">Español</a>
                                    <a class="dropdown-item" href="#">Nederlands</a>
                                    <a class="dropdown-item" href="#">Français</a>
                                    <a class="dropdown-item" href="#">Dansk</a>
                                    <a class="dropdown-item" href="#">Português</a>
                                    <a class="dropdown-item" href="#">Deutsch</a>
                                </div>
                            </div>

                            <div class="lang-changer-drop-up">
                                <a class="menu-btn-changer" href="#"><img src="img/flags/usa.svg" alt="" /> united states</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    <!-- jquery -->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <!-- bootstrap JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <!-- template JavaScript -->
    <script src="js/template-scripts.js"></script>
    <!-- flickity JavaScript -->
    <script src="js/flickity.pkgd.min.js"></script>
    <!-- carousel JavaScript -->
    <script src="owlcarousel/owl.carousel.min.js"></script>
    <!-- parallax JavaScript -->
    <script src="js/parallax.min.js"></script>
    <!-- mailchamp JavaScript -->
    <script src="js/mailchamp.js"></script>
    <!-- bootstrap offcanvas -->
    <script src="js/bootstrap.offcanvas.min.js"></script>
    <!-- touchSwipe JavaScript -->
    <script src="js/jquery.touchSwipe.min.js"></script>
	
	<!-- seconde style additionel JavaScript -->
	<script src="js/particles-code.js"></script>
	<script src="js/particles.js"></script>
	<script src="js/smoothscroll.js"></script>
</body>

</html>